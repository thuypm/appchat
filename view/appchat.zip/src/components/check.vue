<script>

export default {
  name: 'App',
  data () {
   return {
    }
  },
   created:function(){
        this.status();
      },
    methods: {
    status(){
 if(!sessionStorage.user)
 
   this.$router.replace('/signin')
else

    this.$router.replace('/')
      }
    }
}
</script>