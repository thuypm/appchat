import Vue from 'vue'
import Vuex from 'vuex'
import Router from 'vue-router'
import App from '@/App'
import signin from '@/components/signin'
import index from '@/components/index'
import searchFriend from '@/components/searchFriend'
import profile from '@/components/profile'
import check from '@/components/check'
Vue.use(Router)


 const router = new Router({
 
  routes: [
    {
      path: '/',
      name: 'index',
      component: index,
      meta:{requireAut: true
      }
    },
    {
      path: '/signin',
      name: 'signin',
      component: signin ,
      meta:{requireAut: false
      }
    },
    {
      path: '/searchFriend',
      name: 'searchFriend',
      component: searchFriend,
      meta:{requireAut: true
      }
  
    },
    {
      path: '/profile',
      name: 'profile',
      component: profile,
      meta:{requireAut: true
      }
    }

  ]

})
router.beforeEach((to, from, next)=>{
if(to.fullPath == '/signin')
  if(sessionStorage.user != undefined)
    next('/')
  else 
    next();
else
  if(sessionStorage.user != undefined)
      next()
      else
      next('/signin')
 

  
})


export default router